---
layout: default
---

<!--
https://github.com/pages-themes/minimal
**Under construction.** Please visit [myORCID](https://orcid.org/0000-0001-6083-7521). 
[myGithub](https://github.com/iljecho). 
-->

## Profile

Postdoctoral researcher at Instituto de Astrofisica de Andalucia, Spain

PhD at University of Science and Technology (UST) / Korea Astronomy and Space Science Institute (KASI)

E-mail: ijcho(at)iaa.es, astronomy707(at)gmail.com 

[myORCID](https://orcid.org/0000-0001-6083-7521), 
[CV](https://drive.google.com/open?id=1jLSmKw7rUa0xpJYxITZpBwRM2NgGhe2O). 


<!--
You can use HTML elements in Markdown, such as the comment element, and they won't be affected by a markdown parser. However, if you create an HTML element in your markdown file, you cannot use markdown syntax within that element's contents.
-->
